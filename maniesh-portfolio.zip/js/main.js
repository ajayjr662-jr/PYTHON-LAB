/**
 * Maniesh.V - Portfolio Interactive Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide icons if available
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // 1. Mobile Menu Toggle
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  
  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isHidden = mobileMenu.classList.contains('hidden');
      if (isHidden) {
        mobileMenu.classList.remove('hidden');
      } else {
        mobileMenu.classList.add('hidden');
      }
    });

    // Close mobile menu on link click
    const mobileLinks = mobileMenu.querySelectorAll('a');
    mobileLinks.forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
      });
    });
  }

  // 2. Navbar Scroll State & Active Links
  const navbar = document.querySelector('.navbar');
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.classList.add('shadow-sm');
    } else {
      navbar.classList.remove('shadow-sm');
    }

    // Highlight active section
    let current = '';
    const scrollPosition = window.pageYOffset + 120;

    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });

  // 3. Certificate Modal Data & Controller
  const certData = {
    'gnn': {
      title: 'Learning Graph Neural Networks',
      issuer: 'LinkedIn Learning',
      date: 'September 28, 2026',
      duration: '2 hours 13 minutes',
      instructor: 'Shea Hanson, Head of Learning Content Strategy',
      id: 'fb0e759be4e028a41f0f5cbbadc7ed2dcb440971de95d29375413ca7abcb44c3',
      image: 'assets/images/cert-graph-neural-networks.jpg',
      skills: ['Neural Networks', 'Graph Networks', 'Artificial Intelligence (AI)', 'Deep Learning'],
      description: 'Comprehensive study of Graph Neural Network architectures, graph representation learning, node embeddings, and their applications in deep learning and relational reasoning.'
    },
    'discrete-math': {
      title: 'Programming Foundations: Discrete Mathematics',
      issuer: 'LinkedIn Learning',
      date: 'November 05, 2026',
      duration: '3 hours 9 minutes',
      instructor: 'Shea Hanson, Head of Learning Content Strategy',
      id: '445a306eb3690f81c912c8d3b8ad79451f0532c9e8de0d7f62da010cebfcd2f6',
      image: 'assets/images/cert-discrete-mathematics.jpg',
      skills: ['Discrete Mathematics', 'Programming Foundations', 'Algorithms', 'Logic & Sets'],
      description: 'Rigorous foundation in discrete structures, mathematical logic, set theory, combinatorics, and algorithm analysis underpinning modern computer science.'
    }
  };

  const modalBackdrop = document.getElementById('certModal');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalTitle = document.getElementById('modalTitle');
  const modalDate = document.getElementById('modalDate');
  const modalDuration = document.getElementById('modalDuration');
  const modalIdText = document.getElementById('modalIdText');
  const modalImage = document.getElementById('modalImage');
  const modalSkills = document.getElementById('modalSkills');
  const modalDesc = document.getElementById('modalDesc');
  const modalCopyIdBtn = document.getElementById('modalCopyIdBtn');

  let activeCertId = '';

  window.openCertModal = function(certKey) {
    const cert = certData[certKey];
    if (!cert) return;

    activeCertId = cert.id;
    modalTitle.textContent = cert.title;
    modalDate.textContent = cert.date;
    modalDuration.textContent = cert.duration;
    modalIdText.textContent = cert.id;
    modalImage.src = cert.image;
    modalImage.alt = cert.title;
    modalDesc.textContent = cert.description;

    // Render skills
    modalSkills.innerHTML = cert.skills.map(s => 
      `<span class="badge-tag bg-blue-50 text-blue-700 border-blue-200">${s}</span>`
    ).join('');

    modalBackdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  window.closeCertModal = function() {
    modalBackdrop.classList.remove('active');
    document.body.style.overflow = '';
  };

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', window.closeCertModal);
  }

  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) {
        window.closeCertModal();
      }
    });
  }

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalBackdrop.classList.contains('active')) {
      window.closeCertModal();
    }
  });

  // Copy modal Certificate ID
  if (modalCopyIdBtn) {
    modalCopyIdBtn.addEventListener('click', () => {
      if (activeCertId) {
        copyToClipboard(activeCertId, 'Certificate ID copied to clipboard!');
      }
    });
  }

  // 4. Copy to Clipboard Utility with Toast
  window.copyToClipboard = function(text, successMsg = 'Copied to clipboard!') {
    navigator.clipboard.writeText(text).then(() => {
      showToast(successMsg);
    }).catch(err => {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        showToast(successMsg);
      } catch (e) {
        showToast('Failed to copy', 'error');
      }
      document.body.removeChild(textArea);
    });
  };

  // 5. Toast System
  const toastContainer = document.getElementById('toastContainer');

  window.showToast = function(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = 'toast';
    
    const iconColor = type === 'success' ? 'text-emerald-500' : 'text-blue-500';
    const iconName = type === 'success' ? 'check-circle' : 'info';
    
    toast.innerHTML = `
      <div class="${iconColor} flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
      </div>
      <div class="text-sm font-medium text-slate-800">${message}</div>
    `;

    toastContainer.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);

    // Remove after 3.5s
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, 3500);
  };

  // =========================================================================
  // 5.1 DocuRAG Web - Interactive Demo Controller
  // =========================================================================
  const docuRagModal = document.getElementById('docuRagModal');
  const docuRagCloseBtn = document.getElementById('docuRagCloseBtn');
  const docSelector = document.getElementById('docSelector');
  const docContentPreview = document.getElementById('docContentPreview');
  const ragQueryInput = document.getElementById('ragQueryInput');
  const ragSubmitBtn = document.getElementById('ragSubmitBtn');
  const ragHistory = document.getElementById('ragHistory');

  const ragDocuments = {
    'gnn-paper': {
      title: 'Graph Neural Networks & Representation Learning (2026)',
      chunks: [
        {
          id: 'chunk-1',
          content: 'Graph Neural Networks (GNNs) generalize deep learning models to non-Euclidean graph domains. By employing a localized message-passing scheme, each node updates its hidden embedding vector through permutation-invariant aggregation of its immediate neighbors.'
        },
        {
          id: 'chunk-2',
          content: 'Key GNN architectures include Graph Convolutional Networks (GCN), Graph Attention Networks (GAT), and GraphSAGE. These frameworks are utilized for node classification, relation discovery, and link prediction in complex real-world graphs.'
        },
        {
          id: 'chunk-3',
          content: 'In practical applications, GNNs model molecular structures for drug discovery, analyze social networks for community detection, and power recommendation engines through bipartite user-item graphs.'
        }
      ]
    },
    'discrete-math': {
      title: 'Foundations of Discrete Mathematics for CS',
      chunks: [
        {
          id: 'chunk-1',
          content: 'Discrete Mathematics provides the essential mathematical framework for computer science. Core topics include Propositional and First-Order Predicate Logic, Set Theory, Combinatorics, and Graph Theory.'
        },
        {
          id: 'chunk-2',
          content: 'Graph theory structures, composed of vertices V and edges E, formalize network topology, connectivity, shortest paths, and topological sorting algorithms used throughout distributed systems.'
        },
        {
          id: 'chunk-3',
          content: 'Mathematical induction and recurrence relations establish rigorous guarantees for algorithm time complexity, termination proofs, and memory optimization.'
        }
      ]
    },
    'maniesh-profile': {
      title: 'Maniesh.V - Profile & Credentials at Jain University',
      chunks: [
        {
          id: 'chunk-1',
          content: 'Maniesh.V is an active student at Jain (Deemed-to-be University) in Bangalore, India, with a core focus on Artificial Intelligence, Machine Learning, and Computer Science foundations.'
        },
        {
          id: 'chunk-2',
          content: 'Maniesh holds verified LinkedIn Learning certifications in "Learning Graph Neural Networks" and "Programming Foundations: Discrete Mathematics", certified under Shea Hanson, Head of Learning Content Strategy.'
        },
        {
          id: 'chunk-3',
          content: 'Maniesh specializes in modern AI architectures, Graph Neural Networks, discrete algorithmic proofs, and developing clean, minimal web systems like DocuRAG Web and Personal AI.'
        }
      ]
    }
  };

  window.openDocuRagModal = function() {
    if (docuRagModal) {
      docuRagModal.classList.add('active');
      document.body.style.overflow = 'hidden';
      updateDocPreview();
    }
  };

  window.closeDocuRagModal = function() {
    if (docuRagModal) {
      docuRagModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  if (docuRagCloseBtn) {
    docuRagCloseBtn.addEventListener('click', window.closeDocuRagModal);
  }

  function updateDocPreview() {
    if (!docSelector || !docContentPreview) return;
    const selectedKey = docSelector.value;
    const doc = ragDocuments[selectedKey];
    if (doc) {
      docContentPreview.innerHTML = `
        <div class="text-xs font-semibold text-slate-700 mb-2">Active Document: <span class="text-blue-600">${doc.title}</span> (${doc.chunks.length} chunks indexed)</div>
        <div class="space-y-2">
          ${doc.chunks.map((c, i) => `
            <div class="p-2.5 rounded-lg bg-white border border-slate-200 text-[11px] text-slate-600">
              <span class="inline-block px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 font-mono font-bold text-[10px] mr-1">Chunk ${i+1}</span>
              ${c.content}
            </div>
          `).join('')}
        </div>
      `;
    }
  }

  if (docSelector) {
    docSelector.addEventListener('change', updateDocPreview);
  }

  window.runRagQuery = function(presetQuery) {
    const query = presetQuery || (ragQueryInput ? ragQueryInput.value.trim() : '');
    if (!query) {
      showToast('Please type a question or select a preset prompt.');
      return;
    }

    if (ragQueryInput) ragQueryInput.value = '';

    const selectedDocKey = docSelector ? docSelector.value : 'gnn-paper';
    const activeDoc = ragDocuments[selectedDocKey] || ragDocuments['gnn-paper'];

    // 1. Append user query
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-bubble-user';
    userMsg.textContent = query;
    ragHistory.appendChild(userMsg);
    ragHistory.scrollTop = ragHistory.scrollHeight;

    // 2. Append thinking / retrieval indicator
    const loadingElem = document.createElement('div');
    loadingElem.className = 'chat-bubble-ai flex items-center gap-2';
    loadingElem.innerHTML = `
      <span class="text-xs text-slate-500 font-mono flex items-center gap-1.5">
        <svg class="animate-spin h-3.5 w-3.5 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
        </svg>
        Vector embedding search & chunk retrieval in progress...
      </span>
    `;
    ragHistory.appendChild(loadingElem);
    ragHistory.scrollTop = ragHistory.scrollHeight;

    // 3. Simple simulated semantic matching
    setTimeout(() => {
      loadingElem.remove();

      const qWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      let bestChunk = activeDoc.chunks[0];
      let maxScore = 0;

      activeDoc.chunks.forEach((chunk, idx) => {
        const text = chunk.content.toLowerCase();
        let score = 0;
        qWords.forEach(w => {
          if (text.includes(w)) score += 1;
        });
        if (score > maxScore) {
          maxScore = score;
          bestChunk = chunk;
        }
      });

      const similarity = Math.min(98, Math.max(86, 88 + Math.floor(Math.random() * 10)));
      
      const aiResponse = document.createElement('div');
      aiResponse.className = 'chat-bubble-ai space-y-2';
      aiResponse.innerHTML = `
        <div class="flex items-center justify-between border-b border-slate-100 pb-1.5 mb-1">
          <span class="text-[11px] font-bold text-blue-700 flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
            </svg>
            DocuRAG Grounded Answer
          </span>
          <span class="badge-tag bg-emerald-50 text-emerald-700 border-emerald-200 text-[10px]">
            ${similarity}% Match
          </span>
        </div>
        <p class="text-xs text-slate-800 leading-relaxed">
          Based on the retrieved context from <strong>${activeDoc.title}</strong>: ${bestChunk.content}
        </p>
        <div class="doc-chunk-card">
          <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">Retrieved Source Chunk (${bestChunk.id})</div>
          <p class="text-[11px] text-slate-600 italic">"${bestChunk.content}"</p>
        </div>
      `;
      ragHistory.appendChild(aiResponse);
      ragHistory.scrollTop = ragHistory.scrollHeight;
    }, 650);
  };

  if (ragSubmitBtn) {
    ragSubmitBtn.addEventListener('click', () => window.runRagQuery());
  }

  if (ragQueryInput) {
    ragQueryInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        window.runRagQuery();
      }
    });
  }

  // =========================================================================
  // 5.2 Personal AI - Interactive Demo Controller
  // =========================================================================
  const personalAiModal = document.getElementById('personalAiModal');
  const personalAiCloseBtn = document.getElementById('personalAiCloseBtn');
  const aiChatInput = document.getElementById('aiChatInput');
  const aiChatSubmitBtn = document.getElementById('aiChatSubmitBtn');
  const aiChatHistory = document.getElementById('aiChatHistory');

  window.openPersonalAiModal = function() {
    if (personalAiModal) {
      personalAiModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  window.closePersonalAiModal = function() {
    if (personalAiModal) {
      personalAiModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  if (personalAiCloseBtn) {
    personalAiCloseBtn.addEventListener('click', window.closePersonalAiModal);
  }

  const aiKnowledgeBase = [
    {
      keywords: ['jain', 'university', 'college', 'student', 'degree', 'education', 'bangalore'],
      reply: "Maniesh.V is an ambitious student at Jain (Deemed-to-be University) in Bangalore. He is actively specializing in Artificial Intelligence, Graph Neural Networks, and foundational mathematical computation."
    },
    {
      keywords: ['certificat', 'linkedin', 'credential', 'license', 'course'],
      reply: "Maniesh has earned 2 verified LinkedIn Learning credentials: (1) 'Learning Graph Neural Networks' (Sep 2026), and (2) 'Programming Foundations: Discrete Mathematics' (Nov 2026), both completed under Head of Learning Content Strategy Shea Hanson."
    },
    {
      keywords: ['gnn', 'graph neural network', 'graph', 'neural network', 'deep learning'],
      reply: "Graph Neural Networks (GNNs) operate on graph structures through message passing between neighboring nodes. Maniesh applies GNNs to solve node classification, relational mapping, and topology-aware predictions."
    },
    {
      keywords: ['discrete', 'math', 'mathematics', 'logic', 'combinatorics'],
      reply: "Discrete Mathematics is the theoretical foundation of computer science! Maniesh utilizes propositional logic, graph theory, induction, and recurrence relations to construct provably optimal algorithms."
    },
    {
      keywords: ['project', 'docurag', 'personal ai', 'work', 'build'],
      reply: "Maniesh's portfolio highlights: (1) DocuRAG Web — an interactive document retrieval-augmented generation engine, (2) Personal AI Style — an intelligent persona and design consultant, and (3) GNN Node Classification & Link Prediction."
    },
    {
      keywords: ['style', 'ui', 'ux', 'design', 'minimal', 'bright'],
      reply: "Maniesh believes in a 'Simple, Bright & Minimal' aesthetic: ample whitespace, crisp typography (Plus Jakarta Sans), high contrast, soft layered shadows, and meaningful micro-interactions that elevate usability without visual noise."
    },
    {
      keywords: ['contact', 'email', 'hire', 'reach', 'connect'],
      reply: "You can connect with Maniesh directly through the Contact Form on this site, or email at maniesh.v@example.com. He is open to AI internships, research collaborations, and tech opportunities!"
    }
  ];

  window.sendAiChatMessage = function(presetPrompt) {
    const text = presetPrompt || (aiChatInput ? aiChatInput.value.trim() : '');
    if (!text) {
      showToast('Please type a question or select a quick topic.');
      return;
    }

    if (aiChatInput) aiChatInput.value = '';

    // Append User Message
    const userBubble = document.createElement('div');
    userBubble.className = 'chat-bubble-user';
    userBubble.textContent = text;
    aiChatHistory.appendChild(userBubble);
    aiChatHistory.scrollTop = aiChatHistory.scrollHeight;

    // Append Typing Indicator
    const typingBubble = document.createElement('div');
    typingBubble.className = 'chat-bubble-ai flex items-center gap-1.5 py-3';
    typingBubble.innerHTML = `
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    `;
    aiChatHistory.appendChild(typingBubble);
    aiChatHistory.scrollTop = aiChatHistory.scrollHeight;

    setTimeout(() => {
      typingBubble.remove();

      const lower = text.toLowerCase();
      let matched = aiKnowledgeBase.find(k => k.keywords.some(kw => lower.includes(kw)));
      
      let answer = matched 
        ? matched.reply 
        : `Great question about "${text}"! As Maniesh's Personal AI, I can tell you that Maniesh is passionate about applying deep learning, Graph Neural Networks, and mathematical rigor to solve real-world problems. Feel free to reach out via the contact form to collaborate!`;

      const aiBubble = document.createElement('div');
      aiBubble.className = 'chat-bubble-ai space-y-1.5';
      aiBubble.innerHTML = `
        <div class="flex items-center gap-1.5 text-[10px] font-bold text-blue-600 uppercase tracking-wider">
          <span class="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
          Maniesh Personal AI
        </div>
        <p class="text-xs text-slate-800 leading-relaxed">${answer}</p>
      `;
      aiChatHistory.appendChild(aiBubble);
      aiChatHistory.scrollTop = aiChatHistory.scrollHeight;
    }, 550);
  };

  if (aiChatSubmitBtn) {
    aiChatSubmitBtn.addEventListener('click', () => window.sendAiChatMessage());
  }

  if (aiChatInput) {
    aiChatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        window.sendAiChatMessage();
      }
    });
  }

  // =========================================================================
  // 5.3 DNA Fingerprint Simulator - Interactive Electrophoresis Engine
  // =========================================================================
  const dnaModal = document.getElementById('dnaModal');
  const dnaCloseBtn = document.getElementById('dnaCloseBtn');
  const gelChamber = document.getElementById('gelChamber');
  const gelLanesContainer = document.getElementById('gelLanesContainer');
  const runDnaBtn = document.getElementById('runDnaBtn');
  const toggleUvBtn = document.getElementById('toggleUvBtn');
  const resetDnaBtn = document.getElementById('resetDnaBtn');
  const analyzeDnaBtn = document.getElementById('analyzeDnaBtn');
  const voltageSelector = document.getElementById('voltageSelector');
  const dnaProgressText = document.getElementById('dnaProgressText');
  const dnaProgressBar = document.getElementById('dnaProgressBar');
  const dnaAnalysisResult = document.getElementById('dnaAnalysisResult');
  const bubblesContainer = document.getElementById('bubblesContainer');

  let dnaInterval = null;
  let isElectrophoresisRunning = false;
  let isUvActive = false;
  let currentMigrationProgress = 0; // 0 to 100%

  // Lane profiles: bp (base pairs) determines final migration depth
  const laneProfiles = [
    { name: 'DNA Ladder', bands: [1500, 1200, 900, 700, 500, 300, 150], isEvidence: false, isSuspect: false },
    { name: 'Crime Evidence', bands: [1200, 700, 300], isEvidence: true, isSuspect: false },
    { name: 'Suspect 1', bands: [1500, 900, 500], isEvidence: false, isSuspect: 1 },
    { name: 'Suspect 2', bands: [1200, 700, 300], isEvidence: false, isSuspect: 2 }, // Exact match
    { name: 'Suspect 3', bands: [900, 700, 150], isEvidence: false, isSuspect: 3 }
  ];

  window.openDnaModal = function() {
    if (dnaModal) {
      dnaModal.classList.add('active');
      document.body.style.overflow = 'hidden';
      initGelElectrophoresis();
    }
  };

  window.closeDnaModal = function() {
    if (dnaModal) {
      dnaModal.classList.remove('active');
      document.body.style.overflow = '';
      pauseElectrophoresis();
    }
  };

  if (dnaCloseBtn) {
    dnaCloseBtn.addEventListener('click', window.closeDnaModal);
  }

  function initGelElectrophoresis() {
    if (!gelLanesContainer) return;
    gelLanesContainer.innerHTML = '';
    currentMigrationProgress = 0;
    if (dnaProgressBar) dnaProgressBar.style.width = '0%';
    if (dnaProgressText) dnaProgressText.textContent = '0% (Idle)';
    if (dnaAnalysisResult) dnaAnalysisResult.classList.add('hidden');

    laneProfiles.forEach((lane, laneIdx) => {
      const laneElem = document.createElement('div');
      laneElem.className = 'gel-lane flex flex-col items-center';
      laneElem.id = `lane-${laneIdx}`;

      // Well at top
      const well = document.createElement('div');
      well.className = 'gel-well';
      laneElem.appendChild(well);

      // Create bands at well origin (top: 22px)
      lane.bands.forEach((bp, bandIdx) => {
        const band = document.createElement('div');
        band.className = 'dna-band';
        band.id = `band-${laneIdx}-${bandIdx}`;
        band.dataset.bp = bp;
        band.style.top = '22px';
        band.style.opacity = '0.9';
        band.title = `${lane.name}: ${bp} bp`;
        laneElem.appendChild(band);
      });

      gelLanesContainer.appendChild(laneElem);
    });
  }

  function calculateTargetY(bp) {
    // Logarithmic migration in agarose gel: smaller bp moves further
    // Range: 1500 bp -> ~55px, 150 bp -> ~245px
    const minBp = 150;
    const maxBp = 1500;
    const startY = 25;
    const maxY = 245;

    const logMin = Math.log10(minBp);
    const logMax = Math.log10(maxBp);
    const logVal = Math.log10(bp);

    const norm = (logMax - logVal) / (logMax - logMin); // 0 at maxBp, 1 at minBp
    return startY + norm * (maxY - startY);
  }

  function startElectrophoresis() {
    if (currentMigrationProgress >= 100) {
      showToast('Simulation complete! Click UV Mode or Reset to run again.');
      return;
    }

    isElectrophoresisRunning = true;
    if (runDnaBtn) {
      runDnaBtn.innerHTML = `
        <svg class="animate-spin h-3.5 w-3.5 text-white mr-1.5 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
        </svg>
        Pause Electrophoresis
      `;
      runDnaBtn.classList.replace('bg-blue-600', 'bg-amber-600');
    }

    // Start bubbling effect
    startBubbles();

    const voltage = voltageSelector ? parseInt(voltageSelector.value, 10) : 100;
    const speed = (voltage / 100) * 1.5; // step increment

    dnaInterval = setInterval(() => {
      currentMigrationProgress += speed;
      if (currentMigrationProgress >= 100) {
        currentMigrationProgress = 100;
        pauseElectrophoresis();
        showToast('Electrophoresis finished! Click "Analyze Match" to inspect profiles.');
      }

      if (dnaProgressBar) dnaProgressBar.style.width = `${currentMigrationProgress}%`;
      if (dnaProgressText) dnaProgressText.textContent = `${Math.floor(currentMigrationProgress)}% (Running at ${voltage}V)`;

      // Update positions of bands
      laneProfiles.forEach((lane, laneIdx) => {
        lane.bands.forEach((bp, bandIdx) => {
          const band = document.getElementById(`band-${laneIdx}-${bandIdx}`);
          if (band) {
            const targetY = calculateTargetY(bp);
            const currentY = 22 + (targetY - 22) * (currentMigrationProgress / 100);
            band.style.top = `${currentY}px`;
          }
        });
      });
    }, 60);
  }

  function pauseElectrophoresis() {
    isElectrophoresisRunning = false;
    clearInterval(dnaInterval);
    stopBubbles();
    if (runDnaBtn) {
      runDnaBtn.innerHTML = `
        <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        ${currentMigrationProgress >= 100 ? 'Run Again' : 'Resume Electrophoresis'}
      `;
      runDnaBtn.classList.replace('bg-amber-600', 'bg-blue-600');
    }
    if (dnaProgressText && currentMigrationProgress < 100) {
      dnaProgressText.textContent = `${Math.floor(currentMigrationProgress)}% (Paused)`;
    }
  }

  function startBubbles() {
    if (!bubblesContainer) return;
    bubblesContainer.innerHTML = '';
    for (let i = 0; i < 18; i++) {
      const bubble = document.createElement('div');
      bubble.className = 'bubble';
      bubble.style.left = `${Math.random() * 96}%`;
      bubble.style.animationDelay = `${Math.random() * 1.5}s`;
      bubble.style.animationDuration = `${1.2 + Math.random()}s`;
      bubblesContainer.appendChild(bubble);
    }
  }

  function stopBubbles() {
    if (bubblesContainer) bubblesContainer.innerHTML = '';
  }

  if (runDnaBtn) {
    runDnaBtn.addEventListener('click', () => {
      if (isElectrophoresisRunning) {
        pauseElectrophoresis();
      } else {
        if (currentMigrationProgress >= 100) {
          initGelElectrophoresis();
        }
        startElectrophoresis();
      }
    });
  }

  if (toggleUvBtn) {
    toggleUvBtn.addEventListener('click', () => {
      isUvActive = !isUvActive;
      if (gelChamber) {
        if (isUvActive) {
          gelChamber.classList.add('uv-active');
          toggleUvBtn.innerHTML = `
            <svg class="w-3.5 h-3.5 text-yellow-300 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clip-rule="evenodd"></path>
            </svg>
            UV Light: ON
          `;
          toggleUvBtn.classList.replace('bg-slate-100', 'bg-cyan-900');
          toggleUvBtn.classList.replace('text-slate-700', 'text-cyan-200');
          showToast('UV Transilluminator active! Fluorescent bands revealed.');
        } else {
          gelChamber.classList.remove('uv-active');
          toggleUvBtn.innerHTML = `
            <svg class="w-3.5 h-3.5 text-slate-500 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
            </svg>
            UV Light: OFF
          `;
          toggleUvBtn.classList.replace('bg-cyan-900', 'bg-slate-100');
          toggleUvBtn.classList.replace('text-cyan-200', 'text-slate-700');
        }
      }
    });
  }

  if (resetDnaBtn) {
    resetDnaBtn.addEventListener('click', () => {
      pauseElectrophoresis();
      initGelElectrophoresis();
      showToast('Gel chamber reloaded and reset.');
    });
  }

  if (analyzeDnaBtn) {
    analyzeDnaBtn.addEventListener('click', () => {
      if (currentMigrationProgress < 50) {
        showToast('Please run electrophoresis for longer before analyzing bands.');
        return;
      }

      // Automatically switch on UV for clarity
      if (!isUvActive && toggleUvBtn) {
        toggleUvBtn.click();
      }

      // Highlight matching bands on Evidence (Lane 1) and Suspect 2 (Lane 3)
      const evidenceBands = [0, 1, 2];
      evidenceBands.forEach(bIdx => {
        const evBand = document.getElementById(`band-1-${bIdx}`);
        const s2Band = document.getElementById(`band-3-${bIdx}`);
        if (evBand) evBand.classList.add('matched-band');
        if (s2Band) s2Band.classList.add('matched-band');
      });

      if (dnaAnalysisResult) {
        dnaAnalysisResult.classList.remove('hidden');
        dnaAnalysisResult.innerHTML = `
          <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold flex items-center gap-1.5 text-emerald-800 text-sm">
                <svg class="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                </svg>
                Forensic Match Confirmed: Suspect 2
              </span>
              <span class="badge-tag bg-emerald-100 text-emerald-800 border-emerald-300 font-mono font-bold text-[10px]">
                100% Locus Correspondence
              </span>
            </div>
            <p class="leading-relaxed">
              All 3 forensic restriction fragment loci (<strong>1200 bp</strong>, <strong>700 bp</strong>, and <strong>300 bp</strong>) from the Crime Scene Evidence show identical electrophoretic mobility to <strong>Suspect 2</strong>.
            </p>
            <div class="grid grid-cols-3 gap-2 pt-1 font-mono text-[10px]">
              <div class="p-1.5 rounded bg-white/80 border border-emerald-200 text-center">
                <span class="block text-slate-400">Suspect 1</span>
                <span class="text-rose-600 font-bold">Excluded (Mismatch)</span>
              </div>
              <div class="p-1.5 rounded bg-emerald-100/90 border border-emerald-300 text-center">
                <span class="block text-emerald-700">Suspect 2</span>
                <span class="text-emerald-800 font-bold">100% Match (Culprit)</span>
              </div>
              <div class="p-1.5 rounded bg-white/80 border border-emerald-200 text-center">
                <span class="block text-slate-400">Suspect 3</span>
                <span class="text-rose-600 font-bold">Excluded (Mismatch)</span>
              </div>
            </div>
          </div>
        `;
      }
      showToast('Forensic Analysis Complete: Suspect 2 identified!');
    });
  }

  // 6. Contact Form Submission
  const contactForm = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  const submitBtn = document.getElementById('submitBtn');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('senderName').value.trim();
      const email = document.getElementById('senderEmail').value.trim();
      const subject = document.getElementById('messageSubject').value.trim();
      const message = document.getElementById('messageContent').value.trim();

      if (!name || !email || !message) {
        showToast('Please fill out all required fields.', 'error');
        return;
      }

      // Email validation regex
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        showToast('Please enter a valid email address.', 'error');
        return;
      }

      // Button loading state
      const originalBtnHtml = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
        </svg>
        Sending...
      `;

      // Save inquiry to localStorage
      const inquiries = JSON.parse(localStorage.getItem('maniesh_inquiries') || '[]');
      inquiries.push({
        id: Date.now(),
        name,
        email,
        subject: subject || 'General Inquiry',
        message,
        date: new Date().toISOString()
      });
      localStorage.setItem('maniesh_inquiries', JSON.stringify(inquiries));

      // Simulate network request
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnHtml;
        contactForm.reset();

        showToast(`Thank you, ${name}! Your message has been received.`);
        
        if (formStatus) {
          formStatus.classList.remove('hidden');
          formStatus.innerHTML = `
            <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-start gap-3">
              <svg class="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              <div>
                <p class="font-semibold">Message Sent Successfully!</p>
                <p class="text-xs text-emerald-700 mt-0.5">Thank you for reaching out. Maniesh will get back to you shortly.</p>
              </div>
            </div>
          `;

          setTimeout(() => {
            formStatus.classList.add('hidden');
          }, 8000);
        }
      }, 1000);
    });
  }

  // 7. Footer year
  const yearElement = document.getElementById('currentYear');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
});
